SMART PARKING SOFTWARE PROTOTYPE

How to run:
1. Download and extract smart_parking_prototype.zip.
2. Open index.html in a modern browser (Chrome, Edge, Firefox, Safari).
3. No installation, account, server, or internet connection is required.

Features:
- Overview dashboard and sample occupancy statistics
- Interactive 4-level parking map with 24 sample spaces
- Click spaces to inspect/select them
- Toggle demo occupancy and see status update
- Find an available space
- Illustrative navigation action
- Search/filter spaces
- Simulated activity timeline
- Analytics by level
- Export parking status to CSV
- Facility settings for the current browser session

Important limitations:
This is a front-end prototype using simulated data. It is not connected to physical sensors, GPS, indoor positioning, a backend/database, authentication, real booking, or payment services. The blue navigation route is illustrative.
